﻿using System.Collections.Generic;
using UnityEngine;
using UnityEngine.XR;
using UnityEngine.XR.Interaction.Toolkit;

public class HandAnimator : MonoBehaviour
{
    private void Awake()
    {

    }

    private void Update()
    {

    }

    private void CheckGrip()
    {

    }

    private void CheckPointer()
    {

    }

    private void SetFingerTargets(List<Finger> fingers, float value)
    {

    }

    private void SmoothFinger(List<Finger> fingers)
    {

    }

    private void AnimateFinger(List<Finger> fingers)
    {

    }

    private void AnimateFinger(string finger, float blend)
    {

    }
}