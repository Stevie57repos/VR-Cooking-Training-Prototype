﻿using UnityEngine;
using UnityEngine.XR.Interaction.Toolkit;

public class HandPhysics : MonoBehaviour
{
    private void Awake()
    {

    }

    private void Start()
    {

    }

    private void Update()
    {

    }

    private void SetTargetPosition()
    {

    }

    private void SetTargetRotation()
    {

    }

    private void FixedUpdate()
    {

    }

    private void MoveToController()
    {

    }

    private void RotateToController()
    {

    }

    public void TeleportToTarget()
    {

    }
}
